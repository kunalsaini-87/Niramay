export const healthLevelTwo=[
    {
        "name": "Men",
        "categoryId": "men_topwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Women",
        "categoryId": "men_bottomwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Children",
        "categoryId": "men_innerwear_and_sleepwear",
        "parentCategoryId":"men",
        "level":2
    },
    // {
    //     "name": "First-Aid",
    //     "categoryId": "men_footwear",
    //     "parentCategoryId":"men",
    //     "level":2
    // },
    // {
    //     "name": "Children",
    //     "categoryId": "men_personal_care_and_grooming",
    //     "parentCategoryId":"men",
    //     "level":2
    // },
    // {
    //     "name": "Eye Care",
    //     "categoryId": "men_fashion_accessories",
    //     "parentCategoryId":"men",
    //     "level":2
    // },
    // {
    //     "name": "Gadgets",
    //     "categoryId": "men_gadgets",
    //     "parentCategoryId":"men",
    //     "level":2
    // },
    // {
    //     "name": "Bags And Backpacks",
    //     "categoryId": "men_bags_and_backpacks",
    //     "parentCategoryId":"men",
    //     "level":2
    // }
]