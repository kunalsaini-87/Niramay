export const nutritionLevelTwo=[
  {
    "name": "Men",
    "categoryId": "bed_linen_furnishing",
    "parentCategoryName": "Nutrition",
    "parentCategoryId": "nutrition",
    "level": 2
  },
  {
    "name": "Women",
    "categoryId": "flooring",
    "parentCategoryName": "Nutrition",
    "parentCategoryId": "nutrition",
    "level": 2
  },
  {
    "name": "Children",
    "categoryId": "bath",
    "parentCategoryName": "Nutrition",
    "parentCategoryId": "nutrition",
    "level": 2
  },
  // {
  //   "name": "Lamps & Lighting",
  //   "categoryId": "lamps_lighting",
  //   "parentCategoryName": "Furniture",
  //   "parentCategoryId": "furniture",
  //   "level": 2
  // },
  // {
  //   "name": "Home Décor",
  //   "categoryId": "home_decor",
  //   "parentCategoryName": "Furniture",
  //   "parentCategoryId": "furniture",
  //   "level": 2
  // },
  // {
  //   "name": "Kitchen & Table",
  //   "categoryId": "kitchen_table",
  //   "parentCategoryName": "Furniture",
  //   "parentCategoryId": "furniture",
  //   "level": 2
  // },
  // {
  //   "name": "Storage",
  //   "categoryId": "storage",
  //   "parentCategoryName": "Furniture",
  //   "parentCategoryId": "furniture",
  //   "level": 2
  // },

]
